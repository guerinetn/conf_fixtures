## Subresource Integrity

If you are loading Highlight.js via CDN you may wish to use [Subresource Integrity](https://developer.mozilla.org/en-US/docs/Web/Security/Subresource_Integrity) to guarantee that you are using a legimitate build of the library.

To do this you simply need to add the `integrity` attribute for each JavaScript file you download via CDN. These digests are used by the browser to confirm the files downloaded have not been modified.

```html
<script
  src="//cdnjs.cloudflare.com/ajax/libs/highlight.js/11.11.1/highlight.min.js"
  integrity="sha384-5xdYoZ0Lt6Jw8GFfRP91J0jaOVUq7DGI1J5wIyNi0D+eHVdfUwHR4gW6kPsw489E"></script>
<!-- including any other grammars you might need to load -->
<script
  src="//cdnjs.cloudflare.com/ajax/libs/highlight.js/11.11.1/languages/go.min.js"
  integrity="sha384-HdearVH8cyfzwBIQOjL/6dSEmZxQ5rJRezN7spps8E7iu+R6utS8c2ab0AgBNFfH"></script>
```

The full list of digests for every file can be found below.

### Digests

```
sha384-QTDtPWugT5ylY4BegCLYLiNE4eMBrlFVNCv5RjiUQCBChC/v9fi9U1q76ZzrSAvA /es/languages/apache.js
sha384-HPrpX+j31X1o9T5eF99pY7R2u5y8udMGQ5YFLMxlVqNmBsLu2vesOPKXGzEiNKcr /es/languages/apache.min.js
sha384-+QLqOzVprIbDNiTtALJ0CqYF9lCa5YNGtiQE3WogL8TVStFdTMgpkWFBbVdDnj1W /es/languages/asciidoc.js
sha384-3p/AcS9vjLxqOK7hnymyAfIV1SJlGE0eW/iTNNfV56XtUc9kqpliCe3yJL7yZ2R3 /es/languages/asciidoc.min.js
sha384-gRTR/fmk+6+ygbihH/fJvHgmffnOrd/eO7DW5zgu1uN9GBohtDx+OBs0DI0ejigB /es/languages/bash.js
sha384-Pg7b9hYE6kefjcNqAabhv8jOLCVoZubUaM4bZFjUJd0CaaQ14ksDI0GVllMtAF4S /es/languages/bash.min.js
sha384-Gmvct15f4Mo9AXQG5bk5w78N1YjBLXXU3KIV7no+mOVnApXlwfw1dwjfueAwljIV /es/languages/css.js
sha384-1D7DbOic0Z5nM2ldSO9O/EsBfsg/5x7X7So1qnMgscI2ucDevptcg7cTvrD9rL0D /es/languages/css.min.js
sha384-GjF+59AA+OY/6RDsvWxm3u318l0CruHb/Fm3oywrHZWho96FKyPUFnoIKqCKiM4D /es/languages/dockerfile.js
sha384-qyGdaK2usg+DEmSJUcr3Rogi6miy7A1Rn8QlRc71wBlMHpN1Y4b3d8hh2hf31dCu /es/languages/dockerfile.min.js
sha384-vZWLk+C+23/W/GAmv4PXkZSZo82LXul6DdSgWcMzutPxGltitIk38HyLrxRVsFvm /es/languages/ini.js
sha384-CVynu7LzwkkAUiajSi0jprssYhgg9Vi1WSd8iR84Vmi6JdRGq3DT4vvEfjzoxxOK /es/languages/ini.min.js
sha384-g7t9fKR5Tvod4iWv7BQXN+/JMn5GT9sD6FG3h7Fgl+KCv5k4NnnCzEqUe7BMJ9Mv /es/languages/javascript.js
sha384-f7huPivS1dV2T5V+g0aJpgsY7WBHWCsioIq30tpNoXGizD65fWJYGuXXVPNI52VB /es/languages/javascript.min.js
sha384-8CRS96Xb/ZkZlQU+5ffA03XTN6/xY40QAnsXKB0Y+ow1vza1LAkRNPSrZqGSNo53 /es/languages/json.js
sha384-UHzaYxI/rAo84TEK3WlG15gVfPk49XKax76Ccn9qPWYbUxePCEHxjGkV+xp9HcS/ /es/languages/json.min.js
sha384-+KkqXkoHKtuOmUzhZ0BjyV0qjljnS+z6i4fELMEg5brFPtmDIog4zZMhylaBTsVi /es/languages/markdown.js
sha384-E7UvgBH6skA1FIOcn3B2c68GtJzrmZlOOC5p/fsxwihTZG/bBedJZu5PC1+kGX7q /es/languages/markdown.min.js
sha384-V1naTapX08eXbOlk/ff334/j1cqIcSKIL8iFF7fabEzwo0662EJWXaMPDMMdyXZ/ /es/languages/nginx.js
sha384-7QaPTK4CkHm5HP+HbJ7BwALXSAvCln1ofcgr0Myla2I3O6cU/pupqPnajKmyy03P /es/languages/nginx.min.js
sha384-h5xac5UEvgYjdWtd9ajSAtkfHjGTrsb+AfrzOpoAbNLkYaPqOdY1YAb459pAkdhB /es/languages/pgsql.js
sha384-e9t/475eGSjNyO/O9vfEZHxdm21L6W2ZNlupK8+ejvTDnKDq96GjpdXw0z8/P++J /es/languages/pgsql.min.js
sha384-4OPZSHQbxzPqFMOXnndxQ6TZTI/B+J4W9aqTCHxAx/dsPS6GG25kT7wdsf66jJ1M /es/languages/php.js
sha384-VxmvZ2mUpp1EzFijS40RFvIc7vbv/d5PhMxVFG/3HMpVKD4sVvhdV9LThrJDiw9e /es/languages/php.min.js
sha384-Qin+c4lNK1aBTVV9uViy9uCeqaw3milnNPTq/TTWClWsc7ZBMi3kDc4d702bPhbf /es/languages/php-template.js
sha384-/Btu11Y1N5hp8EDB6nZJCif5GWMrSC/bYMh0Re/SH64ZoH2qZRHUtqv1SFRPbNdM /es/languages/php-template.min.js
sha384-R67rULqIohpEyV6aFbjxRv7xhK8v/KteX4cvOFmPcnZ2MTf65Zua+2DzB9MqqXuO /es/languages/scss.js
sha384-WMy5VYgOMFAnHhPJXVDCQ/Y/QPlUrBqNVPtFH6/gGg2F4uaAowyQ0y/9zWEeGpJe /es/languages/scss.min.js
sha384-s1ZfN6xtlNKAZux8QYAG7upUsit3RwK5XDoCAN3g6Kj33RrIqbmkuGjdNF9RvzPM /es/languages/sql.js
sha384-y25cn06synxhYnlKVprZdpakuFWVrm2jvn8pqiF4L85a05CI/6bNeT2+qXbUYIyW /es/languages/sql.min.js
sha384-7HTgKp/l2rzlyrh5vUfbfZVy+Wx1lKO4iGmfqvakienApv21u55lo+Vi+iVg4jY0 /es/languages/yaml.js
sha384-4smueUtgWTorlNLbaQIawnVCcIAuw82NetPOGWN5PbZT/pMr0rjvZXj0EUzJV1nr /es/languages/yaml.min.js
sha384-DAVULDCw5LIrVSnI+OuRkZNCyIr7N0iG7trKt1zmxg7jjJCdIusFEacquZs1aDg3 /languages/apache.js
sha384-ioKFBz7IK1srBqD2/ZtEKYTUj0yv0rnUVBdJ8CdlCnwzifYahEJCYGz5572vamDd /languages/apache.min.js
sha384-lctfFl4oyA21jVOo6OW6n3ng/Yk/tPuM5/h7bMk1gv2nC5tKL4AdpRBugFnTU3j5 /languages/asciidoc.js
sha384-CMXVrh9g9wY0bYvbr18r26rwp495RtmyLa4uqYrnVBmJGG4IlJcfAzmVQunjabDM /languages/asciidoc.min.js
sha384-Jrkpn2hK0TY04skYBXB9fj7mMpKYy7g726cPwXGXf6mdBXnFlTDXFduxikMCRXT7 /languages/bash.js
sha384-BbT8tZtvkh8HPXIvL5RtzuljBwI3gR5KIdYxZyYSyI5C/+KNAGdzAiexvmxuroag /languages/bash.min.js
sha384-bsb3QmLtUiyaiHwtrL4YoAVI9yLsjyqxgoAsk4Zd+ass9rSK1WWRiCDSu/hm8QRp /languages/css.js
sha384-0XGvxIU7Oq1DQMMBr1ORiozzBq3KpZPE/74mJysWRBAop1dZ9Ioq/qRWe8u30Ded /languages/css.min.js
sha384-PF6NlDjoIfHgP6/hbKDRAswvI+dXitquVNX3GAJapyiu+AcQcdicRXJjIp8bj6pM /languages/dockerfile.js
sha384-hly+Rz036+A3/domxShxHoja13X3lfx8nyG3V8aMeOe7Efwu6gUaSrDxq9BKwYk4 /languages/dockerfile.min.js
sha384-izwcylRNWmKKRcyCyrYZyNQekUCyR7Fh1x8nYWNCRJoRDU5JXv6TcqlP4C+4MfIf /languages/ini.js
sha384-NrmnsdarwteQHPGjt70kaQTi1KE0XfOJNX9/VJSg6wWwU6U2nPzjl3iWkgU1cvyx /languages/ini.min.js
sha384-yxv7Fv9ToggiLsR67t98hV5ZRup6XX6xL1Rkbi/cGV5J8y7fosCi9POqlBkiBWFg /languages/javascript.js
sha384-tPOrIubtDHoQU7Rqw0o88ilthGO0/4xEZGB47XrQKWhrc1/SchwsDx+AP74u4nk0 /languages/javascript.min.js
sha384-pUlqdjoNePvHvdi7GVKJJnh/P2T3EvXXodl5j0JtTkbNC4DRH7gwGbcHFa84bFOP /languages/json.js
sha384-3C+cPClJZgjKFYAb0bh35D7im2jasLzgk9eRix3t1c5pk1+x6b+bHghWcdrKwIo3 /languages/json.min.js
sha384-Sk9XW/OOutdl6KS1M9Wson0imuqr0LkpoTRDHi5QFH4MWe0aViI5d86BOVkh8Ds0 /languages/markdown.js
sha384-Rv26WbhHH4MDPzeExq4ECmZUYF942tlfVhqA91Drw1P+Ey55KjihLF9RJENxjWr1 /languages/markdown.min.js
sha384-6yimxEGm9AwY562ggpE8Y+JOP2k/CzmRiB1LCQYpXYotigZw0zrOZy16v63xHMv6 /languages/nginx.js
sha384-CppArOy5YFkx1rJ0ZUWNnkF+CAV5OO9pHj3Fk7Kox4p/9H581UDmEck1buzehnjF /languages/nginx.min.js
sha384-EsaYwDVBonFGod8SpVtelwhaj6/8fG+8zAjciAJPe1DF1eqINj15Ulw8uQtazbcj /languages/pgsql.js
sha384-MBJTfvMpjn9gjGPo9ywtyx6TJL2DqDdoAzzg1z2kWnf9UAsiE6AI2MBDBCL3zQ+X /languages/pgsql.min.js
sha384-0XBmTxpMLuDjB2zdfbi3Lv4Yokm2e1YFGZ9mCmI5887Kpi23jMF5N7rPrf0GdoU/ /languages/php.js
sha384-Bv/Sxv6HlOzYOdV1iQpJTG3xiqGWIIMq9xsFfEX8ss7oNWMgKqOa/J2WSFG2m7Jd /languages/php.min.js
sha384-DQroZ14Erpo7ay5JoNeZEUe41UI7w0Jra2nABCsZVG/EJVO5Zfb2sS1fEt/YGGPe /languages/php-template.js
sha384-LIzUVMUAZRreWHTENKQ/wXuNK17VO4xPf+kR1a0aBKvM3S7vsedCcFJZC7N7vdDt /languages/php-template.min.js
sha384-e5MJZgawCv4c+BexmFUMVQU6dLcIOXdieG/a1FPCIgnlGfBIEUUcFMMo+UrKMOtN /languages/scss.js
sha384-BYdYy4D3IX6eNNlKqsviUjxC6EqavvNwCVDMzmie3QXyArWdCQf+VvvFo4ciaNaW /languages/scss.min.js
sha384-2sXmcW3eKeNDWiLtuq9NgFJC4NsLBN/fDTzZevmcgBrSERv6iO/k+c7r9T09Fb8J /languages/sql.js
sha384-jrnLoVn13sB+/dTfoAYVPhg0tYGQzzuzSGP3WTk8OvKAY0hDejpUXFYYI3bohAyW /languages/sql.min.js
sha384-6GXi9L5BnOWPU6bzwYL78Zscp23qyDdMLZpZvp4mLzvF2qt0eY/DfsPHiFVXq4hv /languages/yaml.js
sha384-A/iMReLA0Bo3tLydBIoOQXQzYnrwL90jkHYUubrtERUGCbIuU7U0EHge0Xd2s5sr /languages/yaml.min.js
sha384-jQmDQu5mlhT3gfWNdmnsEkntLAiGTf68OpxHccQLHAQ/8HaS6/p5p2Hv/vK7gVun /highlight.js
sha384-PiPNkJ19s0Ih4td32ClXH3Te4NXEpfJHsO95RM1IFz1H6DRVmDyQIwq0pyf9gNfs /highlight.min.js
```

